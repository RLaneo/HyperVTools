HyperVTools v1.0.0-beta
=======================

A free inventory and documentation tool for Microsoft Hyper-V.

GETTING STARTED
---------------
1. Run HyperVTools.exe
2. Enter a Hyper-V host name (or "localhost")
3. Click Connect

REQUIREMENTS
------------
- Windows 10/11 or Windows Server 2016+
- .NET Framework 4.7.2 or later

DOCUMENTATION
-------------
https://github.com/rlaneo/hypervtools/wiki

SUPPORT
-------
https://hypervtools.net
https://github.com/rlaneo/hypervtools/issues

LICENSE
-------
Freeware - Free for personal and commercial use.
Copyright 2026 Robert Lane.